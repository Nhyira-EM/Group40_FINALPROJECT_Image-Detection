# Trash finder > 2024-07-29 11:22am
https://universe.roboflow.com/final-project-ap8zj/trash-finder-ddp7n

Provided by a Roboflow user
License: CC BY 4.0

